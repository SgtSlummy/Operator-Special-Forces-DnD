# @operator/chronicle

Portable session chronicle for Davy Jones's existing Discord gateway. The package includes transcripts, consent and corrections, a durable command queue, session controls, reports and delivery receipts. It contains no Discord login, gateway creation, provider configuration, game web host, or default voice receiver.

## Requirements and installation

- Node.js 22.16.0 or later, including `node:sqlite`. Chronicle transactions use `DatabaseSync.isTransaction`, introduced in Node22.16.0; see the [Node SQLite API history](https://nodejs.org/download/release/latest-jod/docs/api/sqlite.html#databaseistransaction).
- Runtime dependency: `@napi-rs/canvas` exactly 1.0.8. Its platform-specific native binary remains an npm dependency; it is not embedded in the JavaScript bundle. Install dependencies for the machine running Davy Jones.
- Build dependency in the source workspace: `esbuild` exactly 0.27.3.
- An existing authenticated Discord client, an Obus-backed provider, and a voice adapter owned by the existing Davy gateway.

Install the local tarball in the Davy project with `npm install /absolute/path/operator-chronicle-0.1.0.tgz`. This package is private and is not published to a registry. Installing it does not start any process or connect to Discord.

## Integration

```js
import { createChronicleRuntime, ChronicleStore, SESSION_COMMAND } from '@operator/chronicle';

const chronicle = createChronicleRuntime({
  client: existingDavyClient,
  config: chronicleConfig,
  transport: existingDiscordTransport,
  provider: obusStoryProvider,
  makeVoice: createSharedDavyCapture,
  store: new ChronicleStore(absoluteChronicleDatabasePath),
  authorizeCommand: scope => currentGameMembership(scope) === 'host',
});

// Existing gateway handlers forward relevant packets/interactions once.
await chronicle.packet(rawPacket);
const handled = await chronicle.handle(rawInteraction, { acknowledged: true });
// acknowledged:true is only valid after the existing handler deferred privately.

// The existing host owns scheduling and shutdown.
await chronicle.tick();
await chronicle.gap(); // On gateway disconnect, pause capture and record a gap.
await chronicle.close();
```

Compose this inside the existing bot. Do not import Operator's standalone `discord/bot.mjs`. Register `SESSION_COMMAND` deliberately through Davy's existing command registration flow; the library never registers commands automatically. A successful composition does not establish live Discord or Obus readiness.

`config` supplies `campaignId`, `guildId`, `channelId`, `journalChannelId`, `dmIds`, `dmRoleId`, `playerIds`, `playerRoleId`, and the absolute `chronicleDir`. The dedicated database path and campaign must match the game web/API configuration. Keep live data outside synced source folders. The runtime takes ownership of its injected chronicle connection and closes it during shutdown; do not pass a shared game database connection or use that connection after `close()`. Concurrent `close()` calls join the same drain. Handle a rejected close before tearing down the host transport: if capture detachment could not be confirmed, the dedicated store remains open and a later close can retry cleanup while new work stays blocked.

The package exports `createChronicleRuntimeCore` and its alias `createChronicleRuntime`, `ChronicleStore`, `ChronicleError`, `ChronicleCommands`, `ChronicleCommandError`, and `SESSION_COMMAND`.

### Required adapters

`provider.write(kind, evidence, context)` returns generated text. `provider.transcribe(wavBytes)` receives one positional WAV `Buffer` and returns a transcript string using local speech recognition when voice capture uses it. The service clears this buffer after processing; do not retain or forward raw audio. The host adapter must route all AI through the private Obus game boundary, enforce routing policy and consent outside prompts, and avoid general personal memory. The package does not select providers or expose their credentials. Provider unavailability must remain an explicit failure; a logged-in Codex account does not enable game use.

`makeVoice({client, config, store, service})` returns synchronously:

- `start(sessionId, hostId, {authorize} = {})`: an async capture attach operation. When supplied, recheck the async `authorize()` callback before and after voice readiness; abort and clean up on denial.
- `stop({flush} = {})`: detach capture and drain pending work as requested. Invalidate pending joins as well as an active capture.
- `revoke(userId)`: discard that user's in-flight capture immediately.
- `status()`: return a safe human-readable status.

Davy's adapter owns the existing voice connection. Chronicle stop, disconnect, and shutdown must not destroy the music player, shared voice connection, or Discord client. Feed opted-in audio to `service.speech(...)`; preserve consent epochs and bounded buffers. The package deliberately has no dependency on `discord.js`, `@discordjs/voice`, or a decoder implementation, so Davy retains one voice implementation and connection owner.

`transport` supplies `respond(interactionId, token, payload)`, `edit(applicationId, token, payload)`, `followup(applicationId, token, payload)`, `member(userId)`, and `send(channelId, payload)`. These are methods over Davy's existing authenticated transport. `member` takes one user ID and fetches current guild membership. Honor payload privacy, `allowed_mentions`, and delivery nonce fields. `send` returns the actual Discord message `{id}`; attach a numeric HTTP `status` to confirmed rejection errors. An unknown send outcome is kept for review rather than automatically repeated.

If Davy already acknowledged an interaction, pass `{acknowledged:true}` so the chronicle edits the existing private reply. Otherwise it issues a private defer itself. Only pass matching `/session` interactions; `handle` returns false for unrelated commands. Do not forward a single interaction through both paths.

`authorizeCommand(scope)` checks current game membership when durable browser commands execute. The default denies queued host work. Discord membership and GM permissions are also checked by the dispatcher. Optional `images` may provide an existing approved image service; omitting it preserves text/manual operation. Safe `log` events contain outcomes rather than credentials or transcript contents.

## Durability boundaries

The queue uses leases, bounded retries and stored receipts. Committed start/pause/end effects are reconciled after restart without replaying global voice actions against a newer session. Voice attachment and provider calls can still be attempted again if a process stops before saving their receipt. The injected adapters must tolerate repeated attempts. Uncertain Discord sends remain paused for review to avoid duplicating a message accepted before a connection failed.

Session capture and external AI consent are separate. Runtime initialization, package import and opening a client do not grant either permission. A gateway gap pauses capture; resuming capture and rejoining voice remain explicit controls.

## Building and checking the artifact

From this package source directory:

```text
npm install --ignore-scripts
npm run build
npm test
npm run pack:artifact
```

The build emits one ESM bundle and local audit manifests. Its esbuild metafile is checked against an explicit eight-file source allowlist. External imports must be Node built-ins or `@napi-rs/canvas`; accidental imports of the Operator platform, bot, default voice, web application or additional dependencies fail the build before output is written.

Tests check source and bundle hashes, the package payload, and installation into an isolated temporary consumer outside the Operator checkout. The installed package is exercised with controlled Obus/Discord/voice adapters, including pre-acknowledged private replies, consent, corrections, queue authorization, saved state and shutdown. These are fixture tests; live Discord audio, model inference, and mixed-account acceptance still require the configured host.

The tarball contains only `package.json`, this README, and `dist/index.mjs`. Local `dist/build-manifest.json`, `dist/metafile.json`, and `artifacts/manifest.json` retain build inputs, hashes and the exact package payload for review; they are not runtime dependencies. No database, audio, tokens, environment files or other project source is packed.
