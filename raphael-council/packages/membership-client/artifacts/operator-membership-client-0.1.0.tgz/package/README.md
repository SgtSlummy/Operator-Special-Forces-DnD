# Operator membership client

Private, server-side client for the existing Davy Jones runtime. This package contains one import-free ES module and has no runtime dependencies. Node 22.16.0 or newer is required. Keep the service credential out of browser bundles, Discord messages and logs.

```js
import { createMembershipClient } from '@operator/membership-client';
const access = createMembershipClient({
  url: 'http://127.0.0.1:38176',
  token: privateMembershipCredential,
});
const runtime = createChronicleRuntimeCore({
  // Supply all other explicit chronicle dependencies from the gateway composition root.
  ...dependencies,
  authorizeCommand: access.authorizeCommand,
});
```

`authorizeCommand({campaign,owner,role})` returns a promise of a boolean. It sends only campaign and owner. The server uses current `GameStore.member({campaign,owner})` and allows only the saved host role. A caller-supplied role never grants access. Configure a campaign allowlist on the server. Discord guild/channel and fresh Discord membership checks remain required in the chronicle adapter.

`status()` returns a promise of a boolean. Both operations fail closed on outage, invalid responses, timeout or redirects. Calls have a three-second default deadline, no retries, no cached authorization, a 1024-byte response limit, and accept only a literal `http://127.0.0.1[:port]` origin. Campaign IDs contain 1–64 letters, numbers, underscores or hyphens; owner IDs contain 17–20 digits. The independent service token contains 32–512 non-whitespace printable ASCII bytes.

The service binds a separate loopback port. Keep it outside the public tunnel. It owns no AI policy, does not route models, and never writes game actions. Obus remains the only game AI runtime and provider-routing authority.

Build from the Operator checkout with `npm run build` in this package, then create the local artifact with `npm pack --pack-destination artifacts`. Installing the resulting tarball requires no sibling checkout, database access, Discord SDK, provider credentials, or registry publication. The host-side service is supplied separately by Operator's `bridge/host.mjs`; this client does not start it or any other process.
